    document.getElementById("demo").onclick = function() {myFunction()};
    function myFunction() {
        document.getElementById("demo").innerHTML = "Discount Code: 1111";
    }
    